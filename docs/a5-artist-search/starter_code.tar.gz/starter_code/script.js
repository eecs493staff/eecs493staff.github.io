/* ------------------- EECS 493 Assignment 5 Starter Code ------------------ */

// Loads Vue. The version number is fixed so that the library cannot change
// while you are working. Leave this line as it is.
import { createApp } from 'https://unpkg.com/vue@3.5.13/dist/vue.esm-browser.prod.js'

createApp({
  data() {
    return {
      // Placeholders, so that index.html has something to render before you
      // have written the search. Both are gone once real results arrive.
      artist1: './img/1.jpg',
      artist2: './img/2.jpg',
    }
  },
  methods: {

  }
}).mount('#app')
