// ===================== EECS 493 Assignment 3 Starter Code =====================

// `defer` guarantees the document is parsed before this file runs, but it does
// not put us in strict mode the way a module would, so we opt in by hand.
"use strict";

// ==================================================================
// ============================= Elements ===========================
// ==================================================================

const gameBoard = document.querySelector("#game-board");

// TODO: ACCESS THE REST OF YOUR DOM ELEMENTS HERE

// ==================================================================
// ======================== Timing constants ========================
// ==================================================================

const TICK_MS = 15;              // how often each asteroid moves
const PLAYER_SPEED = 5;          // pixels per tick, at DESIGN_WIDTH
const PORTAL_EVERY = 6000;
const PORTAL_LASTS = 3000;
const SHIELD_EVERY = 9000;
const SHIELD_LASTS = 3000;

let asteroidSpeed = 3;           // easy: 1, normal: 3, hard: 5

// TODO: ADD YOUR OWN CONSTANTS AND GAME STATE HERE

// ==================================================================
// ======================= The board's size =========================
// ==================================================================

// The speeds above are in pixels per tick at this board width. `scale` below
// adjusts them to whatever width the board actually has.
const DESIGN_WIDTH = 1280;

const board = { width: 0, height: 0, scale: 1 };

// Multiplying every speed by `scale` keeps an asteroid's trip across the board
// the same length of time whatever the window size, so the game is no harder on
// a small screen than on a large one.
//
// Call this once the gameplay screen is on screen. A hidden element measures as
// zero, so measuring too early leaves the board with no size.
function measureBoard() {
  const size = gameBoard.getBoundingClientRect();
  board.width = size.width;
  board.height = size.height;
  board.scale = board.width / DESIGN_WIDTH;
}

window.addEventListener("resize", measureBoard);

// ==================================================================
// ========================== The keyboard ==========================
// ==================================================================

const ARROW_KEYS = {
  ArrowLeft: "left",
  ArrowRight: "right",
  ArrowUp: "up",
  ArrowDown: "down",
};

// Which arrow keys are being held down right now. Reading this on a timer,
// rather than moving the rocket on each keydown, is what lets it keep moving
// while a key is held and travel diagonally when two are held at once.
const held = { left: false, right: false, up: false, down: false };

document.addEventListener("keydown", (event) => {
  if (event.key in ARROW_KEYS) {
    held[ARROW_KEYS[event.key]] = true;
    // Stop the arrow keys from scrolling the page while playing.
    event.preventDefault();
  }

  // TODO: HANDLE ANY OTHER KEYS YOU NEED HERE
});

document.addEventListener("keyup", (event) => {
  if (event.key in ARROW_KEYS) {
    held[ARROW_KEYS[event.key]] = false;
  }
});

// TODO: ADD MORE EVENT HANDLERS HERE

// ==================================================================
// ============================ Asteroids ===========================
// ==================================================================

// Provided for you. You should not need to change this class, but you are
// welcome to add methods to it.
class Asteroid {
  constructor() {
    // TODO: PUT THIS ASTEROID ON THE GAME BOARD, AND STORE ITS ELEMENT HERE.
    this.element = null;

    // Where it is now, and the direction it travels in, as a unit vector.
    this.x = 0;
    this.y = 0;
    this.dx = 0;
    this.dy = 0;

    // Which edge it is heading for, and how far past that edge counts as gone.
    this.exitAxis = "x";
    this.exitAt = 0;
    this.exitSign = "neg";

    this.placeOnEdge();
  }

  // True once the asteroid has travelled past the far edge of the board.
  hasReachedEnd() {
    const position = this.exitAxis === "x" ? this.x : this.y;
    return this.exitSign === "pos" ? position > this.exitAt : position < this.exitAt;
  }

  // Move one step along this asteroid's direction of travel.
  updatePosition() {
    const step = asteroidSpeed * board.scale;
    this.x += this.dx * step;
    this.y += this.dy * step;
    this.element.style.left = `${this.x}px`;
    this.element.style.top = `${this.y}px`;
  }

  // Take this asteroid off the page.
  remove() {
    this.element.remove();
  }

  // Only called by the constructor. Starts the asteroid just off one of the four
  // edges, aimed at a random point on the far side.
  // REMARK: YOU DO NOT NEED TO KNOW HOW THIS METHOD WORKS.
  placeOnEdge() {
    const margin = this.element.offsetWidth;
    const target = {
      x: randomBetween(0, board.width),
      y: randomBetween(0, board.height),
    };

    const fromSide = Math.floor(randomBetween(0, 4));

    if (fromSide === 0) {          // from above, heading down
      this.x = target.x;
      this.y = -margin;
      this.exitAxis = "y";
      this.exitAt = board.height + margin;
      this.exitSign = "pos";
    } else if (fromSide === 1) {   // from below, heading up
      this.x = target.x;
      this.y = board.height + margin;
      this.exitAxis = "y";
      this.exitAt = -margin;
      this.exitSign = "neg";
    } else if (fromSide === 2) {   // from the left, heading right
      this.x = -margin;
      this.y = target.y;
      this.exitAxis = "x";
      this.exitAt = board.width + margin;
      this.exitSign = "pos";
    } else {                       // from the right, heading left
      this.x = board.width + margin;
      this.y = target.y;
      this.exitAxis = "x";
      this.exitAt = -margin;
      this.exitSign = "neg";
    }

    const aimX = this.exitAxis === "x" ? this.exitAt : target.x;
    const aimY = this.exitAxis === "y" ? this.exitAt : target.y;
    const runX = aimX - this.x;
    const runY = aimY - this.y;
    const distance = Math.sqrt(runX * runX + runY * runY);
    this.dx = runX / distance;
    this.dy = runY / distance;

    this.element.style.left = `${this.x}px`;
    this.element.style.top = `${this.y}px`;
  }
}

// Creates one asteroid and keeps it moving until it leaves the board.
// Call measureBoard() before the first time you call this.
function spawnAsteroid() {
  const asteroid = new Asteroid();

  const movement = setInterval(() => {
    // HINT: this is where to check whether this asteroid has hit the rocket, and
    // whether the game is paused or over.

    asteroid.updatePosition();

    if (asteroid.hasReachedEnd()) {
      asteroid.remove();
      clearInterval(movement);
    }
  }, TICK_MS);
}

// ==================================================================
// ======================== Utility functions =======================
// ==================================================================

// Are these two elements overlapping? getBoundingClientRect() gives each one's
// position on screen, so the two can be compared directly.
// Adapted from https://developer.mozilla.org/en-US/docs/Games/Techniques/2D_collision_detection
function isColliding(first, second) {
  const a = first.getBoundingClientRect();
  const b = second.getBoundingClientRect();
  return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
}

// A random number between min and max.
function randomBetween(min, max) {
  return Math.random() * (max - min) + min;
}

// Keeps a value from going below min or above max.
function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

// TODO: ADD YOUR GAME FUNCTIONS HERE
