// ========================= EECS 493 Assignment 2 Starter Code =========================

// Main
$(document).ready(function () {
  // ====== Startup ======
  // TODO: DEFINE YOUR JQUERY SELECTORS HERE

});

// TODO: ADD YOUR EVENT HANDLERS HERE
