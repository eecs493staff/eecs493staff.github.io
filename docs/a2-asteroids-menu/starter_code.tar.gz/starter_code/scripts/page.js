// ===================== EECS 493 Assignment 2 =====================

// `defer` guarantees the document is parsed before this file runs, but it does
// not put us in strict mode the way a module would, so we opt in by hand.
"use strict";


// ==================================================================
// ================== Access your DOM elements here =================
// ==================================================================


// ==================================================================
// ============== Add the logic of screen switching here ============
// ==================================================================

// Show the given screen and hide all the others.

// ==================================================================
// ============= Define your event handlers here ====================
// ==================================================================